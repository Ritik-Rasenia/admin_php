<?php include('config.php');
session_start();
if (!isset($_SESSION['userdata'])) {
    header('Location: login.php');
    exit();
}
$sql = "SELECT * FROM `registration`";
$result = $conn->query($sql);
$data = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">



</head>
<!DOCTYPE html>
<html>

<head>
    <title>Button Toggle Example</title>
    <style>
        .custom-img {
            max-width: 100%;
            height: auto;
        }
    </style>





<body>
    <div class=" container-fluid">
        <div class="row">
            <!-- sidebar -->
            <?php include('header.php'); ?>

            <!-- overlay to close sidebar on small screens -->
            <div class="w-100 vh-100 position-fixed overlay d-none" id="sidebar-overlay"></div>
            <!-- note: in the layout margin auto is the key as sidebar is fixed -->
            <div class="col-md-9 col-lg-10 ml-md-auto px-0">
                <?php include('nav.php'); ?>
                <!-- main content -->
                <main class="container-fluid">
                    <section class="row">
                        <div class="col-md-6 col-lg-3">
                            <!-- card -->
                            <article class="p-4 rounded shadow-sm border-left
               mb-4 bg-primary text-white">
                                <a href="#" class="d-flex align-items-center text-white">
                                    <span class="bi bi-box h5"></span>
                                    <h5 class="ml-2">Total Submission</h5>
                                </a>
                                <h2 class="text-white"><?php
                                $query = "SELECT COUNT(*) as count FROM registration";
                                $query_run = mysqli_query($conn, $query);
                                if (mysqli_num_rows($query_run) > 0) {
                                    $prodItem = mysqli_fetch_array($query_run);
                                    $count = $prodItem['count'];
                                    echo $count;
                                }
                                ?></h2>

                            </article>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <!-- card -->
                            <article class="p-4 rounded shadow-sm border-left
               mb-4 bg-warning text-white">
                                <a href="#" class="d-flex align-items-center text-white">
                                    <span class="bi bi-box h5"></span>
                                    <h5 class="ml-2">Pending Submission</h5>
                                </a>
                                <h2 class="text-white"> <?php
                                $query = "SELECT COUNT(*) as count FROM registration where approval=0";
                                $query_run = mysqli_query($conn, $query);
                                if (mysqli_num_rows($query_run) > 0) {
                                    $prodItem = mysqli_fetch_array($query_run);
                                    $count = $prodItem['count'];
                                    echo $count;
                                }
                                ?></h2>
                            </article>
                        </div>
                        <div class="col-md-6 col-lg-3 ">
                            <article class="p-4 rounded shadow-sm border-left mb-4 bg-success">
                                <a href="#" class="d-flex align-items-center text-white">
                                    <span class="bi bi-person h5"></span>
                                    <h5 class="ml-2">Approved Submission</h5>


                                </a>
                                <h2 class="text-white"> <?php
                                $query = "SELECT COUNT(*) as count FROM registration where approval=1";
                                $query_run = mysqli_query($conn, $query);
                                if (mysqli_num_rows($query_run) > 0) {
                                    $prodItem = mysqli_fetch_array($query_run);
                                    $count = $prodItem['count'];
                                    echo $count;
                                }
                                ?></h2>
                            </article>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <article class="p-4 rounded shadow-sm border-left mb-4 bg-danger">
                                <a href="#" class="d-flex align-items-center text-white">
                                    <span class="bi bi-person-check h5"></span>
                                    <h5 class="ml-2">Rejected Submission</h5>
                                </a>
                                <h2 class="text-white"> <?php
                                $query = "SELECT COUNT(*) as count FROM registration where approval=2";
                                $query_run = mysqli_query($conn, $query);
                                if (mysqli_num_rows($query_run) > 0) {
                                    $prodItem = mysqli_fetch_array($query_run);
                                    $count = $prodItem['count'];
                                    echo $count;
                                }
                                ?></h2>
                            </article>
                        </div>
                        <div class="container-fluid mt-5 ">
                            <div class="card shadow">
                                <div class="card-header bg-dark">
                                    <h3 class="card-title text-white bg-dark">
                                        <form method="post" action="export.php">
                                            Users
                                            <input type="hidden" name="registration" id="registration"
                                                value="registration" required>
                                            <button type="submit" class="btn btn-primary float-right">Export
                                                Excel</button>
                                        </form>
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <table id="example" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Institute</th>
                                                <th>Email</th>
                                                <th>Mobile</th>
                                                <th>Registration For</th>
                                                <th>Attachment</th>
                                                <th>Submission Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($data as $value) { ?>
                                                <tr id="example">
                                                    <td><?php echo $value['id']; ?></td>
                                                    <td><?php echo $value['name']; ?></td>
                                                    <td><?php echo $value['designation']; ?></td>
                                                    <td><?php echo $value['institute']; ?></td>
                                                    <td><?php echo $value['email']; ?></td>
                                                    <td><?php echo $value['contactNumber']; ?></td>
                                                    <td><?php echo $value['regisabs']; ?></td>

                                                    <div class="modal fade" id="imageModal" tabindex="-1" role="dialog"
                                                        aria-labelledby="imageModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="imageModalLabel">Image
                                                                        Preview</h5>
                                                                    <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <!-- Displaying the image inside the modal -->
                                                                    <img src="" alt="Image" class="img-fluid custom-img"
                                                                        id="modalImage">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Image thumbnail with modal trigger -->
                                                    <td>
                                                        <img src="<?php echo htmlspecialchars($value['file_attechment']); ?>"
                                                            alt="<?php echo htmlspecialchars($value['name']); ?>"
                                                            style="width: 100px; height: 50px;" data-toggle="modal"
                                                            data-target="#imageModal"
                                                            onclick="showModal('<?php echo htmlspecialchars($value['file_attechment']); ?>')">
                                                    </td>

                                                    <script>
                                                        function showModal(imageSrc) {
                                                            // Setting the source of the modal image dynamically
                                                            document.getElementById('modalImage').src = imageSrc;
                                                        }
                                                    </script>





                                                    <td><?php echo date('j M Y', strtotime($value['created_at'])); ?></td>

                                                    <td>

                                                        <div class="btn-container">


                                                            <?php
                                                            $status = $value['approval'];
                                                            ?>


                                                            <?php if ($status == 0): ?>
                                                                <a class="approve btn btn-success"
                                                                    value="<?php echo $value['id']; ?>"
                                                                    onclick="sendMail('<?php echo $value['id']; ?>')">Approve</a>
                                                                <a class="reject btn btn-danger"
                                                                    value="<?php echo $value['id']; ?>"
                                                                    onclick="updateStatus('<?php echo $value['id']; ?>', 2)">Reject</a>
                                                            <?php elseif ($status == 1): ?>
                                                                <a class="approve btn btn-dark">Approved</a>
                                                            <?php elseif ($status == 2): ?>
                                                                <a class="reject btn btn-dark">Rejected</a>
                                                            <?php endif; ?>



                                                            <script>
                                                                function sendMail(id) {
                                                                    const xhr = new XMLHttpRequest();
                                                                    xhr.open("POST", "sendEmail.php", true);
                                                                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                                                    xhr.onreadystatechange = function () {
                                                                        if (xhr.readyState == 4 && xhr.status == 200) {
                                                                            alert("Email sent for ID: " + id);
                                                                        }
                                                                    };
                                                                    // Send the request with status = 1 (approved)
                                                                    xhr.send("id=" + id + "&status=1&email=recipient@example.com");
                                                                }

                                                                function updateStatus(id, status) {
                                                                    const xhr = new XMLHttpRequest();
                                                                    xhr.open("POST", "updateStatus.php", true);
                                                                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                                                    xhr.onreadystatechange = function () {
                                                                        if (xhr.readyState == 4 && xhr.status == 200) {
                                                                            alert("Status updated for ID: " + id);

                                                                        }
                                                                    };
                                                                    // Send the request with status = 2 (rejected)
                                                                    xhr.send("id=" + id + "&status=" + status);
                                                                }
                                                            </script>


                                                        </div>
                                                    </td>

                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </section>



                </main>
            </div>
        </div>
    </div>





    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script>


        $(function () {
            $("#example").DataTable({
                "responsive": false,
                "lengthChange": true,
                "autoWidth": true,
                "order": [[0, "desc"]], // Sort by the first column (ID) in descending order
                "buttons": ["copy", "csv", "excel", "pdf", "print"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        });
    </script>




    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>


</body>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">

<!-- jQuery library -->


<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>

<!-- Initialize DataTables -->
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">

<!-- Buttons extension CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">

<!-- jQuery library -->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>

<!-- Buttons extension JS -->
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>




</html>