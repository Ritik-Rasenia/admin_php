<?php

include('config.php');
session_start();
$sql = "SELECT * FROM `registration`";
$result = $conn->query($sql);
$data = $result->fetch_all(MYSQLI_ASSOC);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Users</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">


    <style>
        td {
            word-break: break;

        }
    </style>
</head>

<body>

    <?php include('header.php');  ?>

    <div class="container" style="margin-top:10px;">
        <div class="card shadow p-3">
            <table id="example" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Attechment</th>
                        <th>Action</th>

                    </tr>
                </thead>
                <tbody>

                    <?php foreach ($data as $value) {  ?>
                        <tr>
                            <td><?php echo $value['name'];  ?></td>
                            <td><?php echo $value['contactNumber'];  ?></td>
                            <td><?php echo $value['email'];  ?></td>
                            <td><img src="<?php echo $value['file_attechment']; ?>" alt="<?php $value['name'];  ?>" style="width: 100px; height: 50px;"></td>
                            <td>Approved</td>

                        </tr>

                    <?php } ?>
                </tbody>

            </table>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
</body>

</html>