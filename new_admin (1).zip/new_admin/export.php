<?php
require_once __DIR__ . '/vendor/autoload.php'; // Corrected path
include 'config.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Cell\Hyperlink;

// Define headers and queries for different tables
$tableHeadersMap = [
    'registration' => ['ID', 'Name', 'Designation', 'Institute', 'Email', 'Registration For', 'Contact Number', 'File Attachment', 'Approval', 'Created At', 'Updated At', 'Image'],
];

$queryMap = [
    'registration' => "SELECT `id`, `name`, `designation`, `institute`, `email`, `regisabs`, `contactNumber`, `file_attechment`, `approval`, `created_at`, `updated_at` FROM `registration`",
];

// Get table name from POST request
$table_name = 'registration';

if (!array_key_exists($table_name, $tableHeadersMap) || !array_key_exists($table_name, $queryMap)) {
    die('Invalid table name or headers/query not defined for the given table.');
}

$customHeaders = $tableHeadersMap[$table_name];
$query = $queryMap[$table_name];
$query_run = mysqli_query($conn, $query);

if (!$query_run) {
    die('Query failed: ' . mysqli_error($conn));
}

$data = mysqli_fetch_all($query_run, MYSQLI_ASSOC);

class ExportService
{
    public function exportExcel($data, $customHeaders)
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getProperties()->setTitle("Data Export");
        $spreadsheet->setActiveSheetIndex(0);

        // Set custom headers
        $headerRow = 1;
        $lastColumn = chr(65 + count($customHeaders) - 1); // Calculate the last column (A, B, C, ...)

        foreach ($customHeaders as $index => $header) {
            $columnLetter = chr(65 + $index); // A, B, C, etc.
            $spreadsheet->getActiveSheet()->setCellValue("{$columnLetter}{$headerRow}", $header);
        }

        // Apply styling to headers
        $spreadsheet->getActiveSheet()
            ->getStyle("A{$headerRow}:{$lastColumn}{$headerRow}")
            ->getFont()->setBold(true)
            ->setSize(12);
        $spreadsheet->getActiveSheet()
            ->getStyle("A{$headerRow}:{$lastColumn}{$headerRow}")
            ->getFill()->setFillType(Fill::FILL_SOLID)
            ->getStartColor()->setARGB('FFFF00');
        $spreadsheet->getActiveSheet()
            ->getStyle("A{$headerRow}:{$lastColumn}{$headerRow}")
            ->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        // Fill data
        $rowCount = $headerRow + 1;
        foreach ($data as $row) {
            $spreadsheet->getActiveSheet()->fromArray(array_values($row), null, "A{$rowCount}");

            // Add image if applicable
            if (isset($row['file_attechment']) && file_exists($row['file_attechment'])) {
                $image = new Drawing();
                $image->setPath($row['file_attechment']); // Path to the image
                $image->setHeight(100); // Set image height to 100 (or your desired height)
                $image->setWidth(100); // Set image width to 100 (or your desired width)
                $image->setCoordinates("L{$rowCount}"); // L corresponds to the column of the image
                $image->setOffsetX(10);
                $image->setOffsetY(10);
                $image->setWorksheet($spreadsheet->getActiveSheet());
            }

            // Add hyperlink for file if applicable
            if (isset($row['file_attechment'])) {
                $filePath = $row['file_attechment'];
                $spreadsheet->getActiveSheet()->getCell("H{$rowCount}")->setHyperlink(
                    new Hyperlink('https://proups25.com/uploads/abstract/' . $filePath, 'Download Now')
                );
            }
            $rowCount++;
        }

        // Apply border to data
        $spreadsheet->getActiveSheet()->getStyle("A{$headerRow}:{$lastColumn}{$rowCount}")
            ->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

        // Auto-size columns dynamically based on the number of headers
        foreach (range('A', $lastColumn) as $columnID) {
            $spreadsheet->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
        }

        // Set width for the image column
        $spreadsheet->getActiveSheet()->getColumnDimension('L')->setWidth(30); // Adjust this value as needed

        // Output file to browser
        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $fileName = 'export_' . time() . '.xlsx';
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
        exit;
    }
}

// Export data
$exportService = new ExportService();
$exportService->exportExcel($data, $customHeaders);

?>