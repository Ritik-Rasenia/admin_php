<?php
include 'config.php'; // Include your database connection file.
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include Composer autoload to load PHPMailer.

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize POST data.
    $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
    $status = filter_var($_POST['status'], FILTER_VALIDATE_INT);
    $email = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) : null;

    // Check if required data is valid.
    if ($id === false || $status === false || ($status == 1 && $email === false)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid input data.']);
        exit;
    }

    try {
        // Prepare the SQL statement.
        $stmt = $conn->prepare("UPDATE registration SET approval = ? WHERE id = ?");
        $stmt->bind_param("ii", $status, $id);

        // Execute the query.
        if ($stmt->execute()) {
            // Send email only for approval.
            if ($status == 1 && $email) {
                $mail = new PHPMailer(true);
                try {
                    // Server settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp-relay.brevo.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'info@nuovasoft.com';
                    $mail->Password = 'xsmtpsib-9ef3644a1ebc242e365798b4b4c0497d4a6d0835bc3484f18026886ac8b48a5d-cRDvKabBFSm0AxJZ';                   // SMTP password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Recipients
                    $mail->setFrom('shaurya.vashistha@oakyweb.com', 'Mailer');
                    $mail->addAddress('shaurya.vashistha@oakyweb.com');

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Approval Notification';
                    $mail->Body = '<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: auto; padding: 20px; background-color: #fff; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .header { background-color: #4CAF50; color: white; padding: 10px 0; text-align: center; border-top-left-radius: 10px; border-top-right-radius: 10px; }
        .content { padding: 20px; }
        .footer { background-color: #4CAF50; color: white; padding: 10px 0; text-align: center; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Approval Notification</h1>
        </div>
        <div class="content">
            <p>Dear User,</p>
            <p>We are pleased to inform you that your request has been approved!</p>
            <p>If you have any questions or need further assistance, please do not hesitate to contact us.</p>
            <p>Thank you for your patience and understanding.</p>
            <p>Sincerely,</p>
            <p>Test</p>
        </div>
        <div class="footer">
            <p>&copy;2024 Your Company Name. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
';

                    // Send the email
                    if ($mail->send()) {
                        echo json_encode(['status' => 'success', 'message' => 'Operation successful. Email sent.']);
                    } else {
                        echo json_encode(['status' => 'success', 'message' => 'Operation successful. Email could not be sent.']);
                    }
                } catch (Exception $e) {
                    echo json_encode(['status' => 'error', 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
                }
            } else {
                echo json_encode(['status' => 'success', 'message' => 'Operation successful.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update status.']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'An error occurred: ' . $e->getMessage()]);
    }

    // Close the statement and connection.
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>