<?php
include('config.php');

if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $contactNumber = $_POST['contactNumber'];


  if (empty($name)) {
    $response = array('status' => 'error', 'message' => 'Name is required.');
    echo json_encode($response);
  }

  if (empty($email)) {
    $response = array('status' => 'error', 'message' => 'Email is required.');
    echo json_encode($response);
  }

  if (empty($contactNumber)) {
    $response = array('status' => 'error', 'message' => 'Contact Number is required.');
    echo json_encode($response);
  }

  if (empty($_FILES['attechment']['name'])) {
    $response = array('status' => 'error', 'message' => 'Attechment is required.');
    echo json_encode($response);
  }



  $attechment = $_FILES['attechment']['name'];
  $tempname = $_FILES['attechment']['tmp_name'];
  $folder = "uploads/attechment/" . Date("Y-m-d-H-i-s") . $attechment;
  if (move_uploaded_file($tempname, $folder)) {

    $response = array('status' => 'success', 'message' => 'Attechment uploaded successfully.');

    echo json_encode($response);
  } else {
    $response = array('status' => 'error', 'message' => 'Failed to upload attechment.');
    echo json_encode($response);
  }

  if (!empty($name) && !empty($email) && !empty($contactNumber)) {



    $insertQuery = "INSERT INTO `registration`(`name`, `email`, `contactNumber`, `file_attechment`) VALUES ('$name','$email','$contactNumber','$folder')";
    $result = $conn->query($insertQuery);
    if ($result) {
      $response = array('status' => 'success', 'message' => 'Data inserted successfully.');
      echo json_encode($response);
    } else {
      $response = array('status' => 'error', 'message' => 'Failed to insert data.');
      echo json_encode($response);
    }
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Registration Form</title>
  <link rel="stylesheet" href="style.css" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" />
</head>

<body class="bg-gray-200 flex items-center justify-center h-screen">
  <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">

    <?php
    if (isset($_SESSION['response'])) {
      $response = json_decode($_SESSION['response'], true);
      if ($response['status'] === 'success') {
        echo '<div class="bg-green-500 text-white p-2 rounded mb-4">' . $response['message'] . '</div>';
      } else {
        echo '<div class="bg-red-500 text-white p-2 rounded mb-4">' . $response['message'] . '</div>';
      }
      unset($_SESSION['response']);
    }
    ?>
    <h1 class="text-2xl font-semibold text-center mb-6">Registration</h1>
    <form action="" method="POST" class="space-y-4" enctype="multipart/form-data">
      <div class="relative">
        <i class="fa-solid fa-user form-icon"></i>
        <input type="text" id="name" placeholder="Name" name="name"
          class="input-field w-full border-2 border-gray-300 p-2 rounded" />

        <?php if (isset($_SESSION['response'])) {
          $response = json_decode($_SESSION['response'], true);
          if ($response['status'] === 'error') {
            echo '<span class="text-red-500">' . $response['message'] . '</span>';
          }
        } ?>


      </div>

      <div class="relative">
        <i class="fa-solid fa-envelope form-icon"></i>
        <input type="email" id="email" name="email" placeholder="E-mail Address"
          class="input-field w-full border-2 border-gray-300 p-2 rounded" required />

        <?php if (isset($_SESSION['response'])) {
          $response = json_decode($_SESSION['response'], true);
          if ($response['status'] === 'error') {
            echo '<span class="text-red-500">' . $response['message'] . '</span>';
          }
        } ?>

      </div>
      <div class="relative">
        <i class="fa-solid fa-phone form-icon"></i>
        <input type="tel" id="contactNumber" placeholder="(+91) 1234567890" name="contactNumber"
          class="input-field w-full border-2 border-gray-300 p-2 rounded" required
          oninput="this.value = this.value.replace(/\D/g, '').slice(0, 10);" />

        <?php if (isset($_SESSION['response'])) {
          $response = json_decode($_SESSION['response'], true);
          if ($response['status'] === 'error') {
            echo '<span class="text-red-500">' . $response['message'] . '</span>';
          }
        } ?>
      </div>
      <div class="relative">
        <i class="fa fa-images form-icon fa-1x mt-1"></i>
        <input type="file" id="attechment" name="attechment"
          class="input-field w-full border-2 border-gray-300 p-2 rounded" required />

        <?php if (isset($_SESSION['response'])) {
          $response = json_decode($_SESSION['response'], true);
          if ($response['status'] === 'error') {
            echo '<span class="text-red-500">' . $response['message'] . '</span>';
          }
        } ?>
      </div>
      <button type="submit" name="submit" class="w-full bg-orange-500 text-white p-2 rounded hover:bg-orange-600">
        SUBMIT
      </button>
    </form>
  </div>

  <script src="main.js"></script>
</body>

</html>