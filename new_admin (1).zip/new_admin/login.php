<?php
include('config.php');
session_start();
if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $password = md5($_POST['password']);

  if (empty($email)) {
    $response = array('status' => 'error', 'message' => 'Email is required.');
    $_SESSION['response'] = json_encode($response);
  }

  if (empty($password)) {

    $response = array('status' => 'error', 'message' => 'Password is required.');
    $_SESSION['response'] = json_encode($response);
  }

  if (!empty($email) && !empty($password)) {

    $selectQuery = "SELECT * FROM `admin_login` WHERE `email` = '$email' AND `password` = '$password'";
    $result = $conn->query($selectQuery);

    if ($result->num_rows > 0) {
      $_SESSION['userdata'] = $result->fetch_assoc();
      header('Location: dashboard.php');
      exit();
    } else {

      $response = array('status' => 'error', 'message' => 'Invalid email or password.');
      $_SESSION['response'] = json_encode($response);
    }
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login</title>
  <link rel="stylesheet" href="style.css" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" />
</head>

<body class="bg-gray-200 flex items-center justify-center h-screen">
  <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
    <h1 class="text-2xl font-semibold text-center mb-6">ADMIN LOGIN</h1>

    <?php
    if (isset($_SESSION['response'])) {
      $response = json_decode($_SESSION['response'], true);
      if ($response['status'] === 'success') {
        echo '<div class="bg-green-500 text-white p-2 rounded mb-4">' . $response['message'] . '</div>';
      } else {
        echo '<div class="bg-red-500 text-white p-2 rounded mb-4">' . $response['message'] . '</div>';
      }
      unset($_SESSION['response']);
    }

    ?>
    <form action="" method="POST" class="space-y-4">
      <div class="relative">
        <i class="fa-solid fa-envelope form-icon"></i>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="E-mail Address"
          class="input-field w-full border-2 border-gray-300 p-2 rounded"
          required />

      </div>
      <div class="relative">
        <i class="fa-solid fa-lock form-icon"></i>
        <input
          type="tel"
          id="password"
          placeholder="Password"
          name="password"
          class="input-field w-full border-2 border-gray-300 p-2 rounded"
          required />
      </div>

      <button
        type="submit"
        name="submit"
        class="w-full bg-orange-500 text-white p-2 rounded hover:bg-orange-600">
        SUBMIT
      </button>
    </form>
  </div>

  <script src="main.js"></script>
</body>

</html>