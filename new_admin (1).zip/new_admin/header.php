<div class="col-md-3 col-lg-2 px-0 position-fixed h-100 shadow-sm sidebar bg-dark" id="sidebar">
    <h1 class="bi bi-bootstrap text-primary d-flex my-4 justify-content-center"></h1>
    <div class="list-group rounded-0">
        <a href="dashboard.php"
            class="list-group-item list-group-item-action active border-0 d-flex align-items-center">
            <span class="bi bi-border-all"></span>
            <span class="ml-2">Dashboard</span>
        </a>




    </div>
</div>