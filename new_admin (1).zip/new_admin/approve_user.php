<?php
include 'config.php';
$data = json_decode(file_get_contents('php://input'), true);
$userId = $data['id'];

// Update approval status
$query = "UPDATE registration SET approval = 1 WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database update failed.']);
}
