<?php
$conn = mysqli_connect('localhost', 'root', '', 'new_admin') or die("connection failed");
