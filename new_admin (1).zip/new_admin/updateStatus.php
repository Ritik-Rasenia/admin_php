<?php
include 'config.php'; // Include your database connection file.

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize POST data.
    $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
    $status = filter_var($_POST['status'], FILTER_VALIDATE_INT);

    // Check if required data is valid.
    if ($id === false || $status === false) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid input data.']);
        exit;
    }

    try {
        // Prepare the SQL statement to update approval status.
        $stmt = $conn->prepare("UPDATE registration SET approval = ? WHERE id = ?");
        $stmt->bind_param("ii", $status, $id);

        // Execute the query.
        if ($stmt->execute()) {
            // Return success message.
            echo json_encode(['status' => 'success', 'message' => 'Status updated successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update status.']);
        }

        // Close the statement.
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'An error occurred: ' . $e->getMessage()]);
    }

    // Close the database connection.
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>